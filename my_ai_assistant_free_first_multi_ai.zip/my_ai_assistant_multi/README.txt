MY AI ASSISTANT — FREE-FIRST MULTI-AI STARTER

This is a starter project, not a fully connected “all AIs for free” service. It provides:
- Mobile-friendly chat UI and local chat history
- Compare AIs / Fast Answer selector
- Secure serverless function for provider calls
- Gemini connector when GEMINI_API_KEY is configured
- OpenAI and Anthropic connector code, deliberately DISABLED unless ENABLE_PAID_PROVIDERS=true
- A local coordinator that combines the replies received without making another paid API call

IMPORTANT COST REALITY
- A ChatGPT subscription does not automatically include OpenAI API usage.
- OpenAI API requests are billed separately according to the official pricing page.
- Claude API usage generally requires usage credits.
- This app defaults to free-first behavior and will not call OpenAI/Claude unless you explicitly set ENABLE_PAID_PROVIDERS=true.
- Gemini's free-tier availability, model list, quotas, and terms depend on your account/project and may change. Check current Google AI Studio/API pricing before use.
- Do not enable billing or paid providers unless you understand and approve the cost.

DEPLOY ON NETLIFY FROM ANDROID
1. Download and extract this ZIP on a computer if possible. On Android, a ZIP/file manager can extract it, but creating the Netlify site may be easier in Chrome desktop mode.
2. Create/sign in to a Netlify account and create a new site by importing a Git repository. This starter includes a Netlify Function, so do not just open index.html from your phone's file manager.
3. Upload the project to a private GitHub repository, then connect that repository to Netlify. Build command can be left blank; publish directory is ".".
4. In Netlify, open Site configuration / Environment variables (wording may vary) and add:
   GEMINI_API_KEY = your Gemini API key
   GEMINI_MODEL = gemini-2.5-flash (or a model currently available to your project)
5. Leave ENABLE_PAID_PROVIDERS unset or set it to false. Do not add OpenAI/Anthropic keys for your free-only setup.
6. Trigger a redeploy, open the site's URL, and ask a test question.
7. If you see “No AI provider responded”, check Netlify function logs, the model name, key, quota, and current Google API terms.

ADDING MORE PROVIDERS LATER
- OpenAI and Anthropic code is present, but disabled by default. Before enabling, review their official API pricing and billing setup.
- To enable those providers, add their API keys as Netlify environment variables and set ENABLE_PAID_PROVIDERS=true. Do this only after you choose to accept any charges.
- Add provider-specific model names using OPENAI_MODEL and ANTHROPIC_MODEL, verifying current model IDs in each provider's official documentation.
- A real coordinator model would make another API call and may cost money. This starter deliberately avoids that; its comparison is rule-based and labels limitations honestly.

SECURITY
- Never put provider API keys in index.html, GitHub, a screenshot, or browser localStorage.
- Store secrets only in Netlify environment variables. Use a private repository.
- This starter is for personal testing. For public multi-user deployment, add authentication, request limits, abuse protection, and privacy controls before sharing the URL.
- The browser stores chat history in localStorage on that device. It is not synced or encrypted as a cloud chat history.
- No web-search citations are implemented in this initial starter. Provider responses are not the same as independently verified web research.

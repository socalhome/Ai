// Netlify serverless function. Secrets are read only from environment variables.
// Free-first guard: OpenAI and Anthropic are intentionally not called unless the
// operator explicitly sets ENABLE_PAID_PROVIDERS=true after reviewing costs.
const headers = {
  "Content-Type": "application/json",
  "Cache-Control": "no-store",
  "Access-Control-Allow-Origin": "*"
};

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: { ...headers, "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type" }, body: "" };
  }
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Use POST." }) };
  let body;
  try { body = JSON.parse(event.body || "{}"); } catch { return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON." }) }; }
  const question = String(body.question || "").trim().slice(0, 6000);
  if (!question) return { statusCode: 400, headers, body: JSON.stringify({ error: "Please enter a question." }) };

  const answers = [];
  const failures = [];
  const paidEnabled = process.env.ENABLE_PAID_PROVIDERS === "true";

  // Google Gemini is the only provider attempted by default. Use a model available
  // to your project/free tier and confirm its current terms in Google AI Studio.
  if (process.env.GEMINI_API_KEY) {
    try {
      const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: question }] }], generationConfig: { temperature: 0.3, maxOutputTokens: 1200 } })
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error?.message || `Gemini HTTP ${r.status}`);
      const text = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("\n").trim();
      if (text) answers.push({ provider: "Gemini", text });
      else throw new Error("Gemini returned no text.");
    } catch (e) { failures.push(`Gemini: ${e.message}`); }
  }

  // Explicitly disabled by default to honor free-only preference.
  if (paidEnabled && process.env.OPENAI_API_KEY) {
    try {
      const r = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4.1-mini", input: question, max_output_tokens: 1000 })
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error?.message || `OpenAI HTTP ${r.status}`);
      const text = (j.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n").trim();
      if (text) answers.push({ provider: "OpenAI", text }); else throw new Error("OpenAI returned no text.");
    } catch (e) { failures.push(`OpenAI: ${e.message}`); }
  }
  if (paidEnabled && process.env.ANTHROPIC_API_KEY) {
    try {
      const r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-3-5-haiku-latest", max_tokens: 1000, messages: [{ role: "user", content: question }] })
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error?.message || `Anthropic HTTP ${r.status}`);
      const text = (j.content || []).filter(x => x.type === "text").map(x => x.text).join("\n").trim();
      if (text) answers.push({ provider: "Claude", text }); else throw new Error("Claude returned no text.");
    } catch (e) { failures.push(`Claude: ${e.message}`); }
  }

  if (!answers.length) {
    const paidHint = !paidEnabled ? " Paid providers are disabled because your current preference is free-only." : "";
    return { statusCode: 503, headers, body: JSON.stringify({
      error: "No AI provider responded. Add a Gemini API key to the Netlify environment variables and redeploy, or check your provider quota/errors." + paidHint,
      providers: [], note: failures.join(" | ") || "No provider API keys are configured."
    }) };
  }

  // Coordinator: local synthesis only. No extra paid model call is made.
  const comparison = answers.length === 1
    ? `Answer from ${answers[0].provider}\n\n${answers[0].text}\n\nComparison note: Only one provider is connected, so this is not yet a multi-AI comparison.`
    : `COMBINED ANSWERS AND COMPARISON\n\n${answers.map(a => `--- ${a.provider} ---\n${a.text}`).join("\n\n")}\n\nCOORDINATOR SUMMARY\n- Shared points: Review the responses above for agreement.\n- Differences: Check any claims or recommendations that do not match across providers.\n- Reliability: Verify important claims with primary sources; AI agreement alone is not proof.`;
  return { statusCode: 200, headers, body: JSON.stringify({
    answer: answers[0].text,
    comparison,
    providers: answers.map(a => a.provider),
    note: answers.length === 1 ? "One provider responded. The coordinator did not make a second API call." : "Responses are shown separately; the coordinator summary is rule-based to avoid an extra paid request.",
    sources: []
  }) };
};
